import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {DialogComponent} from './dialog/dialog-component';
import {Hero} from '../hero'

export interface PeriodicElement {
  num:number;
  facility: string;
  type: string;
  inspection: string;
  dueDate:string;
  inspectionDate:string;
}

interface DropDown {
  value: string;
  viewValue: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {num:1,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:2,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:3,facility:'Facility Name',type:'Facility Type',inspection:'airplanemode_active',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:4,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:5,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:6,facility:'Facility Name',type:'Facility Type',inspection:'airplanemode_active',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:7,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:8,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:9,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:10,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:11,facility:'Facility Name',type:'Facility Type',inspection:'airplanemode_active',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:12,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:13,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:14,facility:'Facility Name',type:'Facility Type',inspection:'airplanemode_active',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:15,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:16,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
];
@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})

export class JobsComponent implements OnInit {
  displayedColumns: string[] = ['num','facility', 'type', 'inspection', 'dueDate','inspectionDate'];
  dataSource = ELEMENT_DATA;
  foods: DropDown[] = [
    {value: 'inspection_date', viewValue: 'Inspection Date'},
    {value: 'due_date', viewValue: 'Due'}
  ];

  title = 'My first AGM project';
  lat = 51.678418;
  lng = 7.809007;
  animal: string;
  name: string;
  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }
  openDialog(): void {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '350px',
      data: {name: this.name, animal: this.animal}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }
}
