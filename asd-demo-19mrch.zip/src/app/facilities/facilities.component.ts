import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import {CreateJobComponent} from '../modal/create-job/create-job.component';
export interface Facilities {
  num:number;
  facility: string;
  type: string;
  inspection: string;
  dueDate:string;
  inspectionDate:string;
}

interface DropDown {
  value: string;
  viewValue: string;
}

const ELEMENT_DATA: Facilities[] = [
  {num:1,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:2,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:3,facility:'Facility Name',type:'Facility Type',inspection:'airplanemode_active',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:4,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:5,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:6,facility:'Facility Name',type:'Facility Type',inspection:'airplanemode_active',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:7,facility:'Facility Name',type:'Facility Type',inspection:'camera',dueDate:'Sat',inspectionDate:'2021-03-12'},
  {num:8,facility:'Facility Name',type:'Facility Type',inspection:'directions_bus',dueDate:'Sat',inspectionDate:'2021-03-12'},
];
@Component({
  selector: 'app-facilities',
  templateUrl: './facilities.component.html',
  styleUrls: ['./facilities.component.css']
})
export class FacilitiesComponent implements OnInit {

  displayedColumns: string[] = ['num','facility', 'type', 'inspection', 'dueDate','inspectionDate'];
  dataSource = ELEMENT_DATA;
  foods: DropDown[] = [
    {value: 'inspection_date', viewValue: 'Inspection Date'},
    {value: 'due_date', viewValue: 'Due'}
  ];

  title = 'My first AGM project';
  lat = 51.678418;
  lng = 7.809007;
  city: string;
  name: string;
  food_from_modal: string;

  ngOnInit(): void {
  }
  constructor(public dialog: MatDialog) { }

  openDialog(): void {
    const dialogRef = this.dialog.open(CreateJobComponent, {
      width: '300px',
      data: { name: 'Abc', animal: 'Abc' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      this.city = result;
      this.food_from_modal = result.food;
    });
  }

}
